const slider = document.querySelector(".sped");
const next = document.querySelector(".next");
const prev = document.querySelector(".prev");
const dots = document.querySelectorAll(".dot");


let index = 0;
const slidewidth = 380 + 20;
function updateDots(){
    dots.forEach(dot => {
    dot.classList.remove("active");
    });

    dots[index].classList.add("active");
}
next.addEventListener("click", () => {
if(index < 3){

    index++;

    
    
    slider.style.transform =
    
    `translateX(-${index * slidewidth}px)`;
    
    
    updateDots();
}


});

prev.addEventListener("click", () => {
    
    
    if(index > 0){
    index--;

    slider.style.transform =
    `translateX(-${index * slideWidth}px)`;

    updateDots();
}

});

setInterval(() => {
    if(index < 3){
        index++;
    }
    else{
        index = 0;
    }

    slider.style.transform = `translateX(-${index * slidewidth}px) `;

    updateDots();




}, 6000)






const words = ["Scale", "Cloud", "Speed of Light", "Edge"];

const light = document.querySelector(".light");



let wordIndex = 0;

light.textContent = words[wordIndex];

setInterval(() => {
    light.classList.add("animate");
    setTimeout(() => {
     wordIndex = (wordIndex + 1) % words.length;
    light.textContent = words[wordIndex];
    light.classList.remove("animate");

  }, 500)

    

}, 4000);
  


const buttons = document.querySelectorAll(".yqe button");

buttons.forEach(button => {
    button.addEventListener("click", () => {

        const currentProg = button.closest(".prog");
        const icon = button.querySelector("i");

        // Close all others
        document.querySelectorAll(".prog").forEach(prog => {

            if (prog !== currentProg) {

                prog.classList.remove("active");

                const otherIcon =
                prog.querySelector("button i");

                otherIcon.classList.remove("fa-xmark");
                otherIcon.classList.add("fa-plus");
            }
        });

        // Toggle current one
        currentProg.classList.toggle("active");

        if (currentProg.classList.contains("active")) {

            icon.classList.remove("fa-plus");
            icon.classList.add("fa-xmark");

        } else {

            icon.classList.remove("fa-xmark");
            icon.classList.add("fa-plus");
        }

    });
});

document.body.classList.toggle("dark");

const btn = 
document.querySelector(".theme-btn");
const icon = btn.querySelector("i");

btn.addEventListener("click", () => {
    
document.body.classList.toggle("dark");

if(document.body.classList.contains("dark")){
    icon.classList.replace("fa-moon", "fa-sun");
}else{
    icon.classList.replace("fa-sun", "fa-moon");
}


});










